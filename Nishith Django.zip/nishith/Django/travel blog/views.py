from django.core.checks import messages
from django.shortcuts import redirect, render
from django.contrib.auth.models import User, auth
from travello.models import Destination
from .models import Destination
# Create your views here.









def index(request):

    dests = Destination.objects.all()


    return render(request,"index.html",{'dests':dests})